let cartCount = 0;
let totalAmount = 0;

function addToCart(item, price) {
  cartCount++;
  totalAmount += price;
  document.getElementById('cart').textContent = `Cart: ${cartCount} item${cartCount > 1 ? 's' : ''} | Total: ₹${totalAmount}`;
  alert(`${item} added to cart!`);
}
